#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

{{/*
Expand the name of the chart.
*/}}
{{- define "apisix-ingress-controller-manager.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}
{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "apisix-ingress-controller-manager.name.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}
{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "apisix-ingress-controller-manager.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}
{{/*
Common labels
*/}}
{{- define "apisix-ingress-controller-manager.labels" -}}
helm.sh/chart: {{ include "apisix-ingress-controller-manager.chart" . }}
{{ include "apisix-ingress-controller-manager.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "apisix-ingress-controller-manager.selectorLabels" -}}
{{- if .Values.labelsOverride }}
{{- tpl (.Values.labelsOverride | toYaml) . }}
{{- else }}
app.kubernetes.io/name: {{ include "apisix-ingress-controller-manager.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
{{- end }}

{{/*
Webhook service name - ensure it stays within 63 character limit
*/}}
{{- define "apisix-ingress-controller-manager.webhook.serviceName" -}}
{{- $suffix := "-webhook-svc" -}}
{{- $maxLen := sub 63 (len $suffix) | int -}}
{{- $baseName := include "apisix-ingress-controller-manager.name.fullname" . | trunc $maxLen | trimSuffix "-" -}}
{{- printf "%s%s" $baseName $suffix -}}
{{- end }}

{{/*
Webhook secret name - use value from values.yaml if provided, otherwise generate one
*/}}
{{- define "apisix-ingress-controller-manager.webhook.secretName" -}}
{{- if and .Values.webhook.certificate.provided .Values.webhook.certificate.secretName -}}
{{- .Values.webhook.certificate.secretName -}}
{{- else -}}
{{- $suffix := "-webhook-cert" -}}
{{- $maxLen := sub 63 (len $suffix) | int -}}
{{- $baseName := include "apisix-ingress-controller-manager.name.fullname" . | trunc $maxLen | trimSuffix "-" -}}
{{- printf "%s%s" $baseName $suffix -}}
{{- end -}}
{{- end }}

{{/*
Port of the controller health probe server, taken from config.probeAddr
(e.g. ":8081", "0.0.0.0:8081", "[::]:8081").
*/}}
{{- define "apisix-ingress-controller-manager.probePort" -}}
{{- $addr := .Values.config.probeAddr | default ":8081" -}}
{{- $port := $addr | splitList ":" | last | int -}}
{{- if or (le $port 0) (gt $port 65535) -}}
{{- fail (printf "config.probeAddr %q must end with a valid port, e.g. \":8081\"" $addr) -}}
{{- end -}}
{{- $port -}}
{{- end -}}

{{/*
gatewayProxy.name rendered with tpl, so a parent chart can pass
"{{ .Release.Name }}-...". Empty when it is not set or renders to nothing.
*/}}
{{- define "apisix-ingress-controller-manager.configuredGatewayProxyName" -}}
{{- tpl (.Values.gatewayProxy.name | default "" | toString) . -}}
{{- end -}}

{{/*
Name of the GatewayProxy that the IngressClass references, in the release
namespace: gatewayProxy.name, or "<release name>-config".
*/}}
{{- define "apisix-ingress-controller-manager.gatewayProxyName" -}}
{{- default (printf "%s-config" .Release.Name) (include "apisix-ingress-controller-manager.configuredGatewayProxyName" .) -}}
{{- end -}}
