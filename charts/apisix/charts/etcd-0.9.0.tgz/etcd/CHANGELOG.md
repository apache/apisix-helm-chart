# Changelog

> [!CAUTION]
> This file is kept for backwards compatibility only and is no longer updated. See the [GitHub Releases](https://github.com/CloudPirates-io/helm-charts/releases) page to view changes for each version.

All notable changes to this chart will be documented in this file.

## [0.6.3] - 2026-04-02

- Update image.repository to v3.6.10 (#1202) ([0c177c9d](https://github.com/CloudPirates-io/helm-charts/commit/0c177c9d))

## [0.6.2] - 2026-03-23

- Update image.repository to v3.6.9 (#1174) ([01cd8da5](https://github.com/CloudPirates-io/helm-charts/commit/01cd8da5))

## [0.6.1] - 2026-02-27

- Update charts/etcd/values.yaml etcd-development/etcd to v3.6.8 (patch) (#1069) ([9a9fcc57](https://github.com/CloudPirates-io/helm-charts/commit/9a9fcc57))

## [0.6.0] - 2026-02-16

- [universal]: Bump all charts to common 2.2.0 (#1020) ([cbeb5b19](https://github.com/CloudPirates-io/helm-charts/commit/cbeb5b19))
- [all]: Update documentation to include proper cosign public key ([e42365dc](https://github.com/CloudPirates-io/helm-charts/commit/e42365dc))

## [0.5.3] - 2026-02-02

- Bump etcd version to 0.5.3 and update repo URL ([b71da4b3](https://github.com/CloudPirates-io/helm-charts/commit/b71da4b3))
- Update etcd image registry and repository details ([e944a712](https://github.com/CloudPirates-io/helm-charts/commit/e944a712))
- [etcd]: Fix invalid sha ([801c35e2](https://github.com/CloudPirates-io/helm-charts/commit/801c35e2))

## [0.5.2] - 2026-01-29

- Bump chart version ([d87aa843](https://github.com/CloudPirates-io/helm-charts/commit/d87aa843))

## [0.5.1] - 2026-01-28

- [all]: Update every chart to newest common (#920) ([f8d134d5](https://github.com/CloudPirates-io/helm-charts/commit/f8d134d5))

## [0.5.0] - 2026-01-15

- [etcd,mariadb,rustfs,timescaledb,valkey] add existingClaim (#846) ([17e0af0f](https://github.com/CloudPirates-io/helm-charts/commit/17e0af0f))

## [0.4.0] - 2025-12-06

- [universal] fix statefulset pvc labels (#696) ([b87dbc7a](https://github.com/CloudPirates-io/helm-charts/commit/b87dbc7a))

## [0.3.4] - 2025-12-01

- [universal] add labels to statefulset pvc-templates (#681) ([87624a55](https://github.com/CloudPirates-io/helm-charts/commit/87624a55))
- [etcd]: fix probes https ([12ec01c4](https://github.com/CloudPirates-io/helm-charts/commit/12ec01c4))

## [0.3.3] - 2025-11-18

-  [etcd] Use http for probes (#622) ([c9d20547](https://github.com/CloudPirates-io/helm-charts/commit/c9d20547))

## [0.3.2] - 2025-11-13

- [universal] update readme files (#583) ([e63f5f94](https://github.com/CloudPirates-io/helm-charts/commit/e63f5f94))

## [0.3.1] - 2025-10-28

- [etcd, rabbitmq, redis, zookeeper] add signature verification documentation to readme (#476) ([91c73105](https://github.com/CloudPirates-io/helm-charts/commit/91c73105))

## [0.3.0] - 2025-10-28

- [universal] unify extraEnvVars in all charts (#477) ([4aee7b4a](https://github.com/CloudPirates-io/helm-charts/commit/4aee7b4a))

## [0.2.3] - 2025-10-23

- [universal] Update annotations, labels, podannotations and podlabel (#454) ([cdb38db9](https://github.com/CloudPirates-io/helm-charts/commit/cdb38db9))

## [0.2.2] - 2025-10-22

- [universal]: Support extra secret templating (#444) ([c2b20246](https://github.com/CloudPirates-io/helm-charts/commit/c2b20246))
- [universal] fix all appversions in charts (#417) ([b8debebf](https://github.com/CloudPirates-io/helm-charts/commit/b8debebf))
- [unversal] Add signing informations for artifacthub (#415) ([e761c906](https://github.com/CloudPirates-io/helm-charts/commit/e761c906))
- [universal] use a string instead of a boolean (#413) ([c24d26d6](https://github.com/CloudPirates-io/helm-charts/commit/c24d26d6))
- [universal] improve chart artifact annotations (#404) ([37f1c5be](https://github.com/CloudPirates-io/helm-charts/commit/37f1c5be))
- [universal] Rework all schema json (#393) ([79d1439f](https://github.com/CloudPirates-io/helm-charts/commit/79d1439f))
- [mariadb] add galera cluster support for mariadb (#348) ([b7a63ee8](https://github.com/CloudPirates-io/helm-charts/commit/b7a63ee8))

## [0.2.0] - 2025-10-14

- Update chart.yaml dependencies for indepentent charts (#382) ([87acfb14](https://github.com/CloudPirates-io/helm-charts/commit/87acfb14))

## [0.1.3] - 2025-10-13

- [universal] Fix imagepullsecret in vales.schema.json (#374) ([bcc566c2](https://github.com/CloudPirates-io/helm-charts/commit/bcc566c2))

## [0.1.2] - 2025-10-13

- update helm-chart icon (#360) ([6544ddf6](https://github.com/CloudPirates-io/helm-charts/commit/6544ddf6))
- [universal]: Fix changelog generation (#354) ([2e973c09](https://github.com/CloudPirates-io/helm-charts/commit/2e973c09))

## [0.1.1] - 2025-10-10

- artifact hub repository id (#333) ([36ca7c70](https://github.com/CloudPirates-io/helm-charts/commit/36ca7c70))
- [etcd]: Invalid repo used (#331) ([92617cfd](https://github.com/CloudPirates-io/helm-charts/commit/92617cfd))

## [0.1.0] - 2025-10-10

- Initial release

